(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/crud/views/CrudCreate.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/crud/views/CrudCreate.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-loading-overlay */ "./node_modules/vue-loading-overlay/dist/vue-loading.min.js");
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-loading-overlay/dist/vue-loading.css */ "./node_modules/vue-loading-overlay/dist/vue-loading.css");
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _helpers_mixins_TheContentMixin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../helpers/mixins/TheContentMixin */ "./resources/js/helpers/mixins/TheContentMixin.vue");
/* harmony import */ var vue_form_generator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue-form-generator */ "./node_modules/vue-form-generator/dist/vfg.js");
/* harmony import */ var vue_form_generator__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(vue_form_generator__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var vue_form_generator_dist_vfg_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue-form-generator/dist/vfg.css */ "./node_modules/vue-form-generator/dist/vfg.css");
/* harmony import */ var vue_form_generator_dist_vfg_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(vue_form_generator_dist_vfg_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var vue_multiselect_dist_vue_multiselect_min_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vue-multiselect/dist/vue-multiselect.min.css */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.css");
/* harmony import */ var vue_multiselect_dist_vue_multiselect_min_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect_dist_vue_multiselect_min_css__WEBPACK_IMPORTED_MODULE_7__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







vue_form_generator__WEBPACK_IMPORTED_MODULE_5___default.a.validators.resources.fieldIsRequired = "Поле обязательно для заполнения!";
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "CrudCreate",
  mixins: [_helpers_mixins_TheContentMixin__WEBPACK_IMPORTED_MODULE_4__["default"]],
  data: function data() {
    return {
      title: 'Create CRUD',
      breadcrumbs: [{
        text: 'Главная',
        to: {
          path: '/'
        }
      }, {
        text: 'CRUD',
        to: {
          path: '/crud'
        }
      }, {
        text: this.title,
        active: true
      }],
      // form: {
      //     title: '',
      //     description: '',
      // },
      model: {},
      schema: {
        fields: []
      },
      formOptions: {
        validateAfterLoad: true,
        validateAfterChanged: true,
        validateAsync: true
      },
      formErrors: null,
      isLoading: false
    };
  },
  components: {
    Loading: vue_loading_overlay__WEBPACK_IMPORTED_MODULE_2___default.a,
    "vue-form-generator": vue_form_generator__WEBPACK_IMPORTED_MODULE_5___default.a.component
  },
  created: function () {
    var _created = _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.getFormData();

            case 2:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, this);
    }));

    function created() {
      return _created.apply(this, arguments);
    }

    return created;
  }(),
  mounted: function mounted() {
    this.generateBreadcrumb(this.breadcrumbs);
  },
  methods: {
    // create() {
    //     this.formErrors = null;
    //     this.$v.form.$touch();
    //
    //     if (this.$v.form.$pending || this.$v.form.$error) return;
    //     this.isLoading = true;
    //
    //     axios.post('/api/crud/create', this.$data.form)
    //         .then((response) => {
    //             if (response.data.success === 1) {
    //                 let cruds = this.$store.getters.cruds;
    //                 cruds.push(response.data.crud);
    //                 this.$router.push({path: "/crud"});
    //             }
    //         })
    //         .catch(error => {
    //             if (error.response.data) {
    //                 this.formErrors = error.response.data.errors;
    //                 this.isLoading = false;
    //                 return;
    //             }
    //         });
    // },
    getFormData: function getFormData() {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        var vm;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                vm = _this;
                axios.get("/api/crud/get-form").then(function (response) {
                  if (response.data.success === 1) {
                    _this.model = response.data.model[0];
                    _this.schema['fields'] = response.data.schema;
                    vm.regenerateForm();
                  }
                })["catch"](function (error) {});

              case 2:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    regenerateForm: function regenerateForm() {
      var vm = this;
      vm.schema.fields.forEach(function (data) {
        if (data.model === 'description') {
          data.selectOptions.onSearch = function (searchQuery, id, options) {
            if (searchQuery.length > 2) {
              axios.get("/api/scheme/user/search?query=".concat(searchQuery)).then(function (response) {
                var items = response.data.items;

                for (var i = 0; i < items.length; i++) {
                  if (options.length > 1) {
                    for (var j = 0; j < options.length; j++) {
                      var bool = true;

                      if (items[i].id === option[j].id) {
                        bool = false;
                        break;
                      }

                      if (bool === true) {
                        options.push({
                          id: items[i].id,
                          name: items[i].email
                        });
                      }
                    }
                  } else {
                    options.push({
                      id: items[i].id,
                      name: items[i].email
                    });
                  }
                }
              });
            }
          };
        }
      });
    },
    sendForm: function sendForm() {
      var _this2 = this;

      // let errors = this.$refs.vfg.errors;
      // errors.forEach(function (data) {
      //     console.log(data.field.label, data.error);
      // });
      // console.log(this.$refs.vfg);
      axios.post('/api/crud/create', this.model).then(function (response) {
        console.log(response);

        if (response.data.success === 1) {
          var cruds = _this2.$store.getters.cruds;
          cruds.push(response.data.crud);

          _this2.$router.push({
            path: "/crud"
          });
        }
      })["catch"](function (error) {
        if (error.response.data) {
          _this2.formErrors = error.response.data.errors;
          _this2.isLoading = false;
          return;
        }
      });
    },
    prettyJSON: function prettyJSON(json) {
      if (json) {
        json = JSON.stringify(json, undefined, 4);
        json = json.replace(/&/g, '&').replace(/</g, '<').replace(/>/g, '>');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
          var cls = 'number';

          if (/^"/.test(match)) {
            if (/:$/.test(match)) {
              cls = 'key';
            } else {
              cls = 'string';
            }
          } else if (/true|false/.test(match)) {
            cls = 'boolean';
          } else if (/null/.test(match)) {
            cls = 'null';
          }

          return '<span class="' + cls + '">' + match + '</span>';
        });
      }
    }
  } // validations: {
  //     form: {
  //         title: {
  //             required,
  //             minLength: minLength(3),
  //             maxLength: maxLength(2551)
  //         },
  //         description: {
  //             required,
  //             minLength: minLength(3),
  //             maxLength: maxLength(4000)
  //         }
  //     }
  // }

});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helpers */ "./resources/js/helpers/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: "TheContentMixin",
  methods: {
    generateBreadcrumb: function generateBreadcrumb(breadcrumbs) {
      this.$store.dispatch(_helpers__WEBPACK_IMPORTED_MODULE_0__["SET_BREADCRUMBS"], breadcrumbs);
    },
    getTitle: function getTitle(breadcrumbs) {
      return breadcrumbs[breadcrumbs.length - 1].text;
    },
    setNotifications: function setNotifications(notifications) {
      this.$store.dispatch(_helpers__WEBPACK_IMPORTED_MODULE_0__["SET_NOTIFICATIONS"], notifications);
    },
    scrollToTop: function scrollToTop() {
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/crud/views/CrudCreate.vue?vue&type=template&id=0a38f7b1&scoped=true&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/crud/views/CrudCreate.vue?vue&type=template&id=0a38f7b1&scoped=true& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "card" }, [
      _c("div", { staticClass: "card-header" }, [
        _vm._v("\n            Create CRUD\n        ")
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-body" }, [
        _c("div", { staticClass: "card-text" }, [
          _c(
            "form",
            { attrs: { novalidate: "" } },
            [
              _c("vue-form-generator", {
                ref: "vfg",
                attrs: {
                  schema: _vm.schema,
                  model: _vm.model,
                  options: _vm.formOptions
                }
              }),
              _vm._v(" "),
              _c("div", { staticClass: "form-group" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-primary",
                    attrs: { type: "button" },
                    on: {
                      click: function($event) {
                        return _vm.sendForm()
                      }
                    }
                  },
                  [_vm._v("Submit form")]
                )
              ]),
              _vm._v(" "),
              _vm.formErrors
                ? _c(
                    "div",
                    { staticClass: "alert alert-danger" },
                    _vm._l(_vm.formErrors, function(fieldsError, fieldName) {
                      return _c("div", { key: fieldName }, [
                        _vm._v(
                          "\n                            " +
                            _vm._s(fieldsError.join("\n")) +
                            "\n                        "
                        )
                      ])
                    }),
                    0
                  )
                : _vm._e()
            ],
            1
          ),
          _vm._v(" "),
          _c("div", { staticClass: "panel panel-default" }, [
            _c("div", { staticClass: "panel-heading" }, [_vm._v("Model")]),
            _vm._v(" "),
            _c("div", { staticClass: "panel-body" }, [
              _vm.model
                ? _c("pre", {
                    domProps: { innerHTML: _vm._s(_vm.prettyJSON(_vm.model)) }
                  })
                : _vm._e()
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "panel panel-default" }, [
            _c("div", { staticClass: "panel-heading" }, [_vm._v("Schema")]),
            _vm._v(" "),
            _c("div", { staticClass: "panel-body" }, [
              _vm.model
                ? _c("pre", {
                    domProps: { innerHTML: _vm._s(_vm.prettyJSON(_vm.schema)) }
                  })
                : _vm._e()
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-footer" })
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/crud/views/CrudCreate.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/crud/views/CrudCreate.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CrudCreate_vue_vue_type_template_id_0a38f7b1_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CrudCreate.vue?vue&type=template&id=0a38f7b1&scoped=true& */ "./resources/js/components/crud/views/CrudCreate.vue?vue&type=template&id=0a38f7b1&scoped=true&");
/* harmony import */ var _CrudCreate_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CrudCreate.vue?vue&type=script&lang=js& */ "./resources/js/components/crud/views/CrudCreate.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CrudCreate_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CrudCreate_vue_vue_type_template_id_0a38f7b1_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CrudCreate_vue_vue_type_template_id_0a38f7b1_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "0a38f7b1",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/crud/views/CrudCreate.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/crud/views/CrudCreate.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/crud/views/CrudCreate.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_CrudCreate_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./CrudCreate.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/crud/views/CrudCreate.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_CrudCreate_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/crud/views/CrudCreate.vue?vue&type=template&id=0a38f7b1&scoped=true&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/components/crud/views/CrudCreate.vue?vue&type=template&id=0a38f7b1&scoped=true& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_CrudCreate_vue_vue_type_template_id_0a38f7b1_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./CrudCreate.vue?vue&type=template&id=0a38f7b1&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/crud/views/CrudCreate.vue?vue&type=template&id=0a38f7b1&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_CrudCreate_vue_vue_type_template_id_0a38f7b1_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_CrudCreate_vue_vue_type_template_id_0a38f7b1_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/helpers/mixins/TheContentMixin.vue":
/*!*********************************************************!*\
  !*** ./resources/js/helpers/mixins/TheContentMixin.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TheContentMixin.vue?vue&type=script&lang=js& */ "./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
var render, staticRenderFns




/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  _TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"],
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/helpers/mixins/TheContentMixin.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TheContentMixin.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ })

}]);