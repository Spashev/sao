(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[14],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-loading-overlay */ "./node_modules/vue-loading-overlay/dist/vue-loading.min.js");
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-select */ "./node_modules/vue-select/dist/vue-select.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_select__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vue_select_dist_vue_select_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-select/dist/vue-select.css */ "./node_modules/vue-select/dist/vue-select.css");
/* harmony import */ var vue_select_dist_vue_select_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_select_dist_vue_select_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-loading-overlay/dist/vue-loading.css */ "./node_modules/vue-loading-overlay/dist/vue-loading.css");
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _helpers_mixins_TheContentMixin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../helpers/mixins/TheContentMixin */ "./resources/js/helpers/mixins/TheContentMixin.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


 // select with search/filtering





/* harmony default export */ __webpack_exports__["default"] = ({
  name: "TicketCreate",
  mixins: [_helpers_mixins_TheContentMixin__WEBPACK_IMPORTED_MODULE_5__["default"]],
  data: function data() {
    return {
      title: 'Create Ticket',
      breadcrumbs: [{
        text: 'Главная',
        to: {
          path: '/'
        }
      }, {
        text: 'TroubleTicket',
        to: {
          path: '/troubleticket'
        }
      }, {
        text: this.title,
        active: true
      }],
      test: null,
      form: {
        //id_ticket: null,
        priority: "Emergency",
        // + TODO need change to ID
        tt_type: null,
        // +
        service_type: [],
        // +
        network_type: null,
        // +
        network_list: null,
        region: null,
        // +
        source_name: null,
        // +
        interruption: null,
        affection: null,
        // +
        influence: null,
        // +
        prob_cause_list: null,
        // +
        start_date: null,
        // +
        start_time: null,
        // +
        description: null,
        // +
        old_service_type: [],
        old_region: null
      },
      serviceSearch: '',
      settlementSearch: '',
      formErrors: null,
      isLoading: false,
      service_options: [],
      subnetwork_options: [],
      settlement_options: [],
      problem_causes_options: [],
      influence_options: [{
        value: 1,
        text: 'No'
      }, {
        value: 2,
        text: 'Kcell'
      }, {
        value: 3,
        text: 'Activ'
      }, {
        value: 4,
        text: 'All subs'
      }],
      affection_options: [{
        value: 1,
        text: 'No'
      }, {
        value: 2,
        text: 'Yes'
      }, {
        value: 3,
        text: 'Degradation'
      }],
      tt_type_options: [{
        value: 1,
        text: 'Event'
      }, {
        value: 2,
        text: 'Incident'
      }]
    };
  },
  components: {
    Loading: vue_loading_overlay__WEBPACK_IMPORTED_MODULE_1___default.a,
    vSelect: vue_select__WEBPACK_IMPORTED_MODULE_2___default.a
  },
  watch: {
    settlementSearch: function settlementSearch(newQuery) {
      var _this = this;

      if (newQuery.length > 2) {
        axios.get("/api/catalog/settlement/search?query=".concat(newQuery)).then(function (res) {
          _this.settlement_options = res.data.list;
        });
      }
    },
    serviceSearch: function serviceSearch(newQuery) {
      var _this2 = this;

      if (newQuery.length > 2) {
        axios.get("/api/catalog/service_options?query=".concat(newQuery)).then(function (response) {
          _this2.service_options = response.data.list;
        });
      }
    }
  },
  mounted: function mounted() {
    this.generateBreadcrumb(this.breadcrumbs);
    this.getSubnetworks();
    this.getServiceProblems();
    this.getTicketUpdates();
  },
  methods: {
    getTicketUpdates: function getTicketUpdates() {
      var _this3 = this;

      axios.get("/api/troubleticket/updateData/" + this.$route.params.id).then(function (response) {
        _this3.form.id_ticket = response.data.ticket.id;
        _this3.form.tt_type = response.data.ticket.tt_type;
        _this3.form.network_list = response.data.ticket.network_list;
        _this3.form.source_name = response.data.ticket.source_name;
        _this3.form.interruption = response.data.ticket.interruption;
        _this3.form.affection = response.data.ticket.affection;
        _this3.form.influence = response.data.ticket.influence;
        _this3.form.prob_cause_list = response.data.ticket.prob_cause_list;
        _this3.form.description = response.data.ticket.description;
        _this3.form.start_date = response.data.ticket.start_date;
        _this3.form.start_time = response.data.ticket.start_time;
        _this3.form.service_type = response.data.ticket.service_list;
        _this3.form.old_service_type = response.data.ticket.service_list;
        _this3.form.region = response.data.city_list;
        _this3.form.old_region = response.data.city_list;
      });
    },
    getSubnetworks: function getSubnetworks() {
      var _this4 = this;

      axios.get("/api/catalog/subnetworks_list").then(function (response) {
        _this4.subnetwork_options = response.data.list;
      });
    },
    getServiceProblems: function getServiceProblems() {
      var _this5 = this;

      axios.get("/api/catalog/problem_cause_list").then(function (response) {
        _this5.problem_causes_options = response.data.list;
      });
    },
    update: function update() {
      var _this6 = this;

      axios.post('/api/troubleticket/update/' + this.$data.form.id_ticket, this.$data.form).then(function (response) {
        if (response.data.success === 1) {
          _this6.$router.push({
            path: "/troubleticket/" + response.data.ticket.id
          });
        }
      })["catch"](function (error) {
        if (error.response.data) {
          _this6.formErrors = error.response.data.errors;
          _this6.isLoading = false;
          return;
        }
      });
    }
  },
  validations: {
    form: {
      description: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["minLength"])(3),
        maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["maxLength"])(4000)
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helpers */ "./resources/js/helpers/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: "TheContentMixin",
  methods: {
    generateBreadcrumb: function generateBreadcrumb(breadcrumbs) {
      this.$store.dispatch(_helpers__WEBPACK_IMPORTED_MODULE_0__["SET_BREADCRUMBS"], breadcrumbs);
    },
    getTitle: function getTitle(breadcrumbs) {
      return breadcrumbs[breadcrumbs.length - 1].text;
    },
    setNotifications: function setNotifications(notifications) {
      this.$store.dispatch(_helpers__WEBPACK_IMPORTED_MODULE_0__["SET_NOTIFICATIONS"], notifications);
    },
    scrollToTop: function scrollToTop() {
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=template&id=f9b9d3a6&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=template&id=f9b9d3a6& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("div", { staticClass: "card" }, [
      _c("div", { staticClass: "card-header" }, [
        _vm._v("\n            Create Ticket\n        ")
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-body" }, [
        _c(
          "form",
          {
            on: {
              submit: function($event) {
                $event.preventDefault()
                return _vm.update()
              }
            }
          },
          [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-md-5" }, [
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", { attrs: { for: "name" } }, [
                      _vm._v("Тип сервиса")
                    ]),
                    _vm._v(" "),
                    _c("v-select", {
                      attrs: { options: _vm.service_options, multiple: "" },
                      on: {
                        search: function(query) {
                          return (_vm.serviceSearch = query)
                        }
                      },
                      model: {
                        value: _vm.form.service_type,
                        callback: function($$v) {
                          _vm.$set(_vm.form, "service_type", $$v)
                        },
                        expression: "form.service_type"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", { attrs: { for: "name" } }, [
                      _vm._v("Подсеть")
                    ]),
                    _vm._v(" "),
                    _c("v-select", {
                      attrs: { options: _vm.subnetwork_options },
                      model: {
                        value: _vm.form.network_list,
                        callback: function($$v) {
                          _vm.$set(_vm.form, "network_list", $$v)
                        },
                        expression: "form.network_list"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", { attrs: { for: "name" } }, [_vm._v("Город")]),
                    _vm._v(" "),
                    _c("v-select", {
                      attrs: { options: _vm.settlement_options, multiple: "" },
                      on: {
                        search: function(query) {
                          return (_vm.settlementSearch = query)
                        }
                      },
                      model: {
                        value: _vm.form.region,
                        callback: function($$v) {
                          _vm.$set(_vm.form, "region", $$v)
                        },
                        expression: "form.region"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group" },
                  [
                    _c("label", { attrs: { for: "name" } }, [
                      _vm._v("Возможная причина проблемы")
                    ]),
                    _vm._v(" "),
                    _c("v-select", {
                      attrs: { options: _vm.problem_causes_options },
                      model: {
                        value: _vm.form.prob_cause_list,
                        callback: function($$v) {
                          _vm.$set(_vm.form, "prob_cause_list", $$v)
                        },
                        expression: "form.prob_cause_list"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c("div", { staticClass: "form-group" }, [
                  _c("label", { attrs: { for: "source_name" } }, [
                    _vm._v("Возможный источник проблемы")
                  ]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.form.source_name,
                        expression: "form.source_name"
                      }
                    ],
                    staticClass: "form-control",
                    attrs: { type: "text", id: "source_name" },
                    domProps: { value: _vm.form.source_name },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.form, "source_name", $event.target.value)
                      }
                    }
                  })
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "form-group" }, [
                  _c("label", { attrs: { for: "description" } }, [
                    _vm._v("Описание")
                  ]),
                  _vm._v(" "),
                  _c("textarea", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.form.description,
                        expression: "form.description"
                      }
                    ],
                    staticClass: "form-control",
                    class: { "is-invalid": _vm.$v.form.description.$error },
                    staticStyle: { height: "auto" },
                    attrs: { id: "description", rows: "4" },
                    domProps: { value: _vm.form.description },
                    on: {
                      blur: function($event) {
                        return _vm.$v.form.description.$touch()
                      },
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.form, "description", $event.target.value)
                      }
                    }
                  }),
                  _vm._v(" "),
                  !_vm.$v.form.description.required
                    ? _c("div", { staticClass: "invalid-feedback" }, [
                        _vm._v(
                          "Обязательно для\n                                заполнения\n                            "
                        )
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  !_vm.$v.form.description.minLength
                    ? _c("div", { staticClass: "invalid-feedback" }, [
                        _vm._v(
                          "\n                                Минимальная длина " +
                            _vm._s(
                              _vm.$v.form.description.$params.minLength.min
                            ) +
                            " символов. Сейчас\n                                " +
                            _vm._s(_vm.form.description.length) +
                            ".\n                            "
                        )
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  !_vm.$v.form.description.maxLength
                    ? _c("div", { staticClass: "invalid-feedback" }, [
                        _vm._v(
                          "\n                                Максимальная длина " +
                            _vm._s(
                              _vm.$v.form.description.$params.maxLength.max
                            ) +
                            " символов. Сейчас\n                                " +
                            _vm._s(_vm.form.description.length) +
                            ".\n                            "
                        )
                      ])
                    : _vm._e()
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-7" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-6" }, [
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", { attrs: { for: "tt_type" } }, [
                          _vm._v("Тип тикеты")
                        ]),
                        _vm._v(" "),
                        _c(
                          "b-form-group",
                          [
                            _c("b-form-radio-group", {
                              attrs: {
                                id: "radio-group-3",
                                options: _vm.tt_type_options,
                                name: "tt_type"
                              },
                              model: {
                                value: _vm.form.tt_type,
                                callback: function($$v) {
                                  _vm.$set(_vm.form, "tt_type", $$v)
                                },
                                expression: "form.tt_type"
                              }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", { attrs: { for: "affection" } }, [
                          _vm._v("Влияние на сервис")
                        ]),
                        _vm._v(" "),
                        _c(
                          "b-form-group",
                          [
                            _c("b-form-radio-group", {
                              attrs: {
                                id: "radio-group-2",
                                options: _vm.affection_options,
                                name: "affection"
                              },
                              model: {
                                value: _vm.form.affection,
                                callback: function($$v) {
                                  _vm.$set(_vm.form, "affection", $$v)
                                },
                                expression: "form.affection"
                              }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "form-group" },
                      [
                        _c("label", { attrs: { for: "influence" } }, [
                          _vm._v("Бренд")
                        ]),
                        _vm._v(" "),
                        _c(
                          "b-form-group",
                          [
                            _c("b-form-radio-group", {
                              attrs: {
                                id: "radio-group-1",
                                options: _vm.influence_options,
                                name: "influence"
                              },
                              model: {
                                value: _vm.form.influence,
                                callback: function($$v) {
                                  _vm.$set(_vm.form, "influence", $$v)
                                },
                                expression: "form.influence"
                              }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-6" }, [
                    _c("div", { staticClass: "form-group" }, [
                      _c("label", { attrs: { for: "priority" } }, [
                        _vm._v("Приоритет")
                      ]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.form.priority,
                            expression: "form.priority"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "text", id: "priority", disabled: "" },
                        domProps: { value: _vm.form.priority },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.form, "priority", $event.target.value)
                          }
                        }
                      })
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "form-row" }, [
                      _c("div", { staticClass: "form-group col-md-6" }, [
                        _c("label", { attrs: { for: "start_date" } }, [
                          _vm._v("Дата начала")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.start_date,
                              expression: "form.start_date"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: { type: "date", id: "start_date" },
                          domProps: { value: _vm.form.start_date },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "start_date",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "form-group col-md-6" }, [
                        _c("label", { attrs: { for: "start_time" } }, [
                          _vm._v("Время начала")
                        ]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.form.start_time,
                              expression: "form.start_time"
                            }
                          ],
                          staticClass: "form-control",
                          attrs: { type: "time", id: "start_time" },
                          domProps: { value: _vm.form.start_time },
                          on: {
                            input: function($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.form,
                                "start_time",
                                $event.target.value
                              )
                            }
                          }
                        })
                      ])
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "border",
                    staticStyle: { "min-height": "200px" }
                  },
                  [
                    _c(
                      "table",
                      { staticClass: "table table-sm table-light" },
                      _vm._l(_vm.form.service_type, function(item, index) {
                        return _c("tr", { key: index }, [
                          _c("td", { staticClass: "border-bottom" }, [
                            _c("div", [
                              _vm._v(
                                "\n                                            " +
                                  _vm._s(item.label) +
                                  "\n                                        "
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "form-row" }, [
                              _c(
                                "div",
                                { staticClass: "form-group col-md-7" },
                                [
                                  _c(
                                    "select",
                                    {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value:
                                            _vm.form.service_type[index]
                                              .id_influence,
                                          expression:
                                            "form.service_type[index].id_influence"
                                        }
                                      ],
                                      staticClass: "form-control",
                                      attrs: { id: "query_type" },
                                      on: {
                                        change: function($event) {
                                          var $$selectedVal = Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function(o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function(o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                          _vm.$set(
                                            _vm.form.service_type[index],
                                            "id_influence",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        }
                                      }
                                    },
                                    [
                                      _c(
                                        "option",
                                        { attrs: { disabled: "", value: "" } },
                                        [_vm._v("Выберите")]
                                      ),
                                      _vm._v(" "),
                                      _vm._l(item.influence_options, function(
                                        option
                                      ) {
                                        return _c(
                                          "option",
                                          {
                                            domProps: {
                                              value: option.id_influence
                                            }
                                          },
                                          [
                                            _vm._v(
                                              "\n                                                        " +
                                                _vm._s(option.label) +
                                                "\n                                                    "
                                            )
                                          ]
                                        )
                                      })
                                    ],
                                    2
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                { staticClass: "form-group col-md-3" },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value:
                                          _vm.form.service_type[index]
                                            .start_date,
                                        expression:
                                          "form.service_type[index].start_date"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "date", id: "start_date" },
                                    domProps: {
                                      value:
                                        _vm.form.service_type[index].start_date
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form.service_type[index],
                                          "start_date",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                { staticClass: "form-group col-md-2" },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value:
                                          _vm.form.service_type[index]
                                            .start_time,
                                        expression:
                                          "form.service_type[index].start_time"
                                      }
                                    ],
                                    staticClass: "form-control",
                                    attrs: { type: "time", id: "start_time" },
                                    domProps: {
                                      value:
                                        _vm.form.service_type[index].start_time
                                    },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.form.service_type[index],
                                          "start_time",
                                          $event.target.value
                                        )
                                      }
                                    }
                                  })
                                ]
                              )
                            ])
                          ])
                        ])
                      }),
                      0
                    )
                  ]
                ),
                _vm._v(" "),
                _vm.formErrors
                  ? _c(
                      "div",
                      { staticClass: "alert alert-danger" },
                      _vm._l(_vm.formErrors, function(fieldsError, fieldName) {
                        return _c("div", { key: fieldName }, [
                          _vm._v(
                            "\n                                " +
                              _vm._s(fieldsError.join("\n")) +
                              "\n                            "
                          )
                        ])
                      }),
                      0
                    )
                  : _vm._e()
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "float-right" }, [
              _c(
                "button",
                {
                  staticClass: "btn btn-sm btn-outline-primary",
                  attrs: { type: "submit" }
                },
                [_vm._v("Изменить")]
              ),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn btn-sm btn-outline-dark",
                  on: {
                    click: function($event) {
                      _vm.modalVisibility = false
                    }
                  }
                },
                [_vm._v("Отмена")]
              )
            ])
          ]
        )
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card-footer" }, [
        _vm._v("   \n            " + _vm._s(_vm.test) + "\n        ")
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/troubleticket/views/TicketUpdate.vue":
/*!**********************************************************************!*\
  !*** ./resources/js/components/troubleticket/views/TicketUpdate.vue ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TicketUpdate_vue_vue_type_template_id_f9b9d3a6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TicketUpdate.vue?vue&type=template&id=f9b9d3a6& */ "./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=template&id=f9b9d3a6&");
/* harmony import */ var _TicketUpdate_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TicketUpdate.vue?vue&type=script&lang=js& */ "./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TicketUpdate_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TicketUpdate_vue_vue_type_template_id_f9b9d3a6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TicketUpdate_vue_vue_type_template_id_f9b9d3a6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/troubleticket/views/TicketUpdate.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketUpdate_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TicketUpdate.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketUpdate_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=template&id=f9b9d3a6&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=template&id=f9b9d3a6& ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketUpdate_vue_vue_type_template_id_f9b9d3a6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TicketUpdate.vue?vue&type=template&id=f9b9d3a6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketUpdate.vue?vue&type=template&id=f9b9d3a6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketUpdate_vue_vue_type_template_id_f9b9d3a6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketUpdate_vue_vue_type_template_id_f9b9d3a6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/helpers/mixins/TheContentMixin.vue":
/*!*********************************************************!*\
  !*** ./resources/js/helpers/mixins/TheContentMixin.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TheContentMixin.vue?vue&type=script&lang=js& */ "./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
var render, staticRenderFns




/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  _TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"],
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/helpers/mixins/TheContentMixin.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TheContentMixin.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ })

}]);