(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[15],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketView.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketView.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _troubleticketStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../troubleticketStore */ "./resources/js/components/troubleticket/troubleticketStore.js");
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-loading-overlay */ "./node_modules/vue-loading-overlay/dist/vue-loading.min.js");
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-loading-overlay/dist/vue-loading.css */ "./node_modules/vue-loading-overlay/dist/vue-loading.css");
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _helpers_mixins_TheContentMixin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../helpers/mixins/TheContentMixin */ "./resources/js/helpers/mixins/TheContentMixin.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  name: "TroubleTicketView",
  mixins: [_helpers_mixins_TheContentMixin__WEBPACK_IMPORTED_MODULE_4__["default"]],
  data: function data() {
    return {
      breadcrumbs: [{
        text: 'Главная',
        to: {
          path: '/'
        }
      }, {
        text: 'Trouble Ticket',
        to: {
          path: '/troubleticket'
        }
      }, {
        text: this.$route.params.id,
        active: true
      }],
      isLoading: false,
      isSubticketCreate: false,
      ticket_cities: [],
      ticket_services: [],
      ticket_actions: [],
      ticket_change_histories: [],
      ticket_histories: [],
      subticket_actions: [],
      subticket_action: {},
      subticket_form: {
        id_ticket: null,
        id_act: null,
        id_act_bck: null,
        act_title: null,
        source_name: '',
        description: ''
      },
      subticket_list: [],
      selected_action: {},
      action_comment: ''
    };
  },
  components: {
    Loading: vue_loading_overlay__WEBPACK_IMPORTED_MODULE_2___default.a
  },
  created: function () {
    var _created = _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.getData();

            case 2:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, this);
    }));

    function created() {
      return _created.apply(this, arguments);
    }

    return created;
  }(),
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_5__["mapGetters"])(["troubleticket", "actions", "sub_actions"])),
  mounted: function mounted() {
    this.generateBreadcrumb(this.breadcrumbs);
    this.getTicketCities();
    this.getTicketActions();
    this.getTicketHistories();
    this.getSubTicketActions();
    this.getSubTicketList();
  },
  methods: {
    getData: function getData() {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return _this.$store.dispatch(_troubleticketStore__WEBPACK_IMPORTED_MODULE_1__["SET_TROUBLE_TICKET"], _this.$route.params.id);

              case 2:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    // TODO need remove, and load from ticket
    getTicketCities: function getTicketCities() {
      var _this2 = this;

      axios.get("/api/troubleticket/ticket_cities/search?id=".concat(this.$route.params.id)).then(function (response) {
        _this2.ticket_cities = response.data.list;
      });
    },
    getTicketActions: function getTicketActions() {
      var _this3 = this;

      axios.get("/api/troubleticket/ticket_actions/search?id=".concat(this.$route.params.id)).then(function (response) {
        _this3.ticket_actions = response.data.list;
      });
    },
    getTicketHistories: function getTicketHistories() {
      var _this4 = this;

      axios.get("/api/troubleticket/ticket_histories/search?id=".concat(this.$route.params.id)).then(function (response) {
        _this4.ticket_histories = response.data.list;
      });
    },
    getSubTicketList: function getSubTicketList() {
      var _this5 = this;

      axios.get("/api/troubleticket/ticket_subticket_list/search?id=".concat(this.$route.params.id)).then(function (response) {
        _this5.subticket_list = response.data.list;
      });
    },
    getSubTicketActions: function getSubTicketActions() {
      var _this6 = this;

      axios.get("/api/troubleticket/ticket_sub_actions/search?id=".concat(this.$route.params.id)).then(function (response) {
        _this6.subticket_actions = response.data.list;
      });
    },
    changeAction: function changeAction(action) {
      this.selected_action = action;
    },
    changeAction2: function changeAction2() {
      var _this7 = this;

      var form = {
        'id': this.troubleticket.id,
        'id_act': this.selected_action.id,
        'id_act_bck': this.selected_action.back_act_id,
        'act_title': this.selected_action.act_title,
        'comment': this.action_comment
      };
      console.log('tickets', form);
      axios.post('/api/troubleticket/update-action/', form).then(function (response) {
        if (response.data.success === 1) {
          _this7.$router.push({
            path: '/troubleticket'
          });
        }
      })["catch"](function (error) {});
    },
    createSubticket: function createSubticket() {
      var _this8 = this;

      this.subticket_form.id_ticket = this.troubleticket.id;
      this.subticket_form.id_act = this.subticket_action.id;
      this.subticket_form.id_act_bck = this.subticket_action.back_act_id;
      this.subticket_form.act_title = this.subticket_action.act_title;
      axios.post('/api/troubleticket/create_subticket', this.$data.subticket_form).then(function (response) {
        if (response.data.success === 1) {
          console.log('tickets', response.data.ticket);
          _this8.subticket_list = response.data.list;
          _this8.isSubticketCreate = false;

          _this8.getTicketHistories();
        }
      })["catch"](function (error) {
        if (error.response.data) {
          _this8.formErrors = error.response.data.errors;
          _this8.isLoading = false;
          return;
        }
      });
    }
    /*
    getTicketHistory() {
        axios.get(`/api/troubleticket/ticket_history`)
            .then((response) => {
                this.ticket_history = response.data.list;
            });
    }
    
    */

  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helpers */ "./resources/js/helpers/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: "TheContentMixin",
  methods: {
    generateBreadcrumb: function generateBreadcrumb(breadcrumbs) {
      this.$store.dispatch(_helpers__WEBPACK_IMPORTED_MODULE_0__["SET_BREADCRUMBS"], breadcrumbs);
    },
    getTitle: function getTitle(breadcrumbs) {
      return breadcrumbs[breadcrumbs.length - 1].text;
    },
    setNotifications: function setNotifications(notifications) {
      this.$store.dispatch(_helpers__WEBPACK_IMPORTED_MODULE_0__["SET_NOTIFICATIONS"], notifications);
    },
    scrollToTop: function scrollToTop() {
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketView.vue?vue&type=template&id=74eb2d09&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketView.vue?vue&type=template&id=74eb2d09&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _vm.troubleticket
      ? _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-header" }, [
            _vm._v(
              "\n            Сервис тикет #" +
                _vm._s(_vm.troubleticket.id) +
                " (" +
                _vm._s(_vm.troubleticket.source_name) +
                ")\n        "
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card-body" }, [
            _c("div", { staticClass: "card-text" }, [
              _c("p"),
              _vm._v(" "),
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-md-5" }, [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-weight": "bold",
                        "font-style": "italic",
                        "font-size": "0.8rem"
                      }
                    },
                    [_vm._v("Основная информация по тикету:")]
                  ),
                  _c("br"),
                  _vm._v(" "),
                  _c("div", { staticClass: "border-top" }, [
                    _c("p"),
                    _vm._v(" "),
                    _c("dl", { staticClass: "row" }, [
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Тип тикета")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm.troubleticket.tt_type === 1
                          ? _c("span", [_vm._v("Event")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.tt_type === 2
                          ? _c("span", [_vm._v("Incident")])
                          : _vm._e()
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Приоритет")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm.troubleticket.priority === 1
                          ? _c("span", [_vm._v("Low")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.priority === 2
                          ? _c("span", [_vm._v("Medium")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.priority === 3
                          ? _c("span", [_vm._v("High")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.priority === 4
                          ? _c("span", [_vm._v("Critical")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.priority === 5
                          ? _c("span", [_vm._v("Emergency")])
                          : _vm._e()
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Сеть")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(_vm._s(_vm.troubleticket.network.network))
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Подсеть")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(_vm._s(_vm.troubleticket.network.subnetwork_1))
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Подсеть 2")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(
                          _vm._s(_vm.troubleticket.network.subnetwork_2) +
                            ": " +
                            _vm._s(_vm.troubleticket.network.subnetwork_3)
                        )
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Объект")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(_vm._s(_vm.troubleticket.source_name))
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Влияние на сервис")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm.troubleticket.affection === 1
                          ? _c("span", [_vm._v("Нет")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.affection === 2
                          ? _c("span", [_vm._v("Да")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.affection === 3
                          ? _c("span", [_vm._v("Деградация")])
                          : _vm._e()
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Бренд")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm.troubleticket.influence === 1
                          ? _c("span", [_vm._v("Нет")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.influence === 2
                          ? _c("span", [_vm._v("Kcell")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.influence === 3
                          ? _c("span", [_vm._v("Activ")])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.troubleticket.influence === 4
                          ? _c("span", [_vm._v("Все")])
                          : _vm._e()
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Предп. причина")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(
                          _vm._s(_vm.troubleticket.prob_cause.cause_1_name) +
                            ": " +
                            _vm._s(_vm.troubleticket.prob_cause.cause_2_name)
                        )
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Время начала")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(_vm._s(_vm.troubleticket.formatted_start_date))
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Время создания")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(_vm._s(_vm.troubleticket.formatted_created_date))
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Последнее действие")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(_vm._s(_vm.troubleticket.act_title))
                      ]),
                      _vm._v(" "),
                      _c("dt", { staticClass: "col-md-4 text-right" }, [
                        _vm._v("Доп. информация")
                      ]),
                      _vm._v(" "),
                      _c("dd", { staticClass: "col-md-8" }, [
                        _vm._v(_vm._s(_vm.troubleticket.description))
                      ])
                    ])
                  ]),
                  _vm._v(" "),
                  _c("hr"),
                  _vm._v(" "),
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-weight": "bold",
                        "font-style": "italic",
                        "font-size": "0.8rem"
                      }
                    },
                    [_vm._v("История изменения тикета:")]
                  ),
                  _c("br"),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "border-top",
                      staticStyle: { "min-height": "200px" }
                    },
                    [
                      _c(
                        "div",
                        {
                          staticClass: "accordion",
                          attrs: { role: "tablist" }
                        },
                        _vm._l(_vm.troubleticket.change_list, function(
                          item,
                          index
                        ) {
                          return _c(
                            "b-card",
                            {
                              key: index,
                              staticClass: "mb-1",
                              attrs: { "no-body": "" }
                            },
                            [
                              _c(
                                "b-card-header",
                                {
                                  staticClass: "p-1",
                                  attrs: { "header-tag": "header", role: "tab" }
                                },
                                [
                                  _c(
                                    "button",
                                    {
                                      directives: [
                                        {
                                          name: "b-toggle",
                                          rawName: "v-b-toggle",
                                          value: "accordion-" + item.id,
                                          expression: "'accordion-' + item.id"
                                        }
                                      ],
                                      staticClass:
                                        "btn btn-sm btn-outline-primary"
                                    },
                                    [
                                      _vm._v(
                                        "\n                                            #" +
                                          _vm._s(item.id) +
                                          "\n                                        "
                                      )
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c("div", { staticClass: "float-right" }, [
                                    _c(
                                      "span",
                                      { staticStyle: { "font-size": "12px" } },
                                      [
                                        _vm._v(
                                          "\n                                                " +
                                            _vm._s(item.created_by) +
                                            "\n                                            "
                                        )
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "span",
                                      {
                                        staticStyle: {
                                          "font-size": "12px",
                                          "font-style": "italic"
                                        }
                                      },
                                      [
                                        _vm._v(
                                          "\n                                                // " +
                                            _vm._s(item.created_at) +
                                            "\n                                            "
                                        )
                                      ]
                                    )
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "b-collapse",
                                {
                                  attrs: {
                                    id: "accordion-" + item.id,
                                    accordion: "my-accordion",
                                    role: "tabpanel"
                                  }
                                },
                                [
                                  _c(
                                    "b-card-body",
                                    [
                                      _c(
                                        "b-card-text",
                                        _vm._l(item.group_list, function(
                                          item2,
                                          index2
                                        ) {
                                          return _c(
                                            "div",
                                            {
                                              key: index2,
                                              staticClass: "border-bottom",
                                              staticStyle: {
                                                "font-size": "14px",
                                                "font-style": "italic"
                                              }
                                            },
                                            [
                                              _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "badge badge-primary"
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(item2.field_label)
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "div",
                                                { staticClass: "row" },
                                                [
                                                  _c(
                                                    "div",
                                                    { staticClass: "col-md-5" },
                                                    [
                                                      _vm._v(
                                                        "\n                                                            " +
                                                          _vm._s(
                                                            item2.old_field_value
                                                          ) +
                                                          "\n                                                        "
                                                      )
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    { staticClass: "col-md-1" },
                                                    [
                                                      _vm._v(
                                                        "\n                                                            ->\n                                                        "
                                                      )
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    { staticClass: "col-md-6" },
                                                    [
                                                      _vm._v(
                                                        "\n                                                            " +
                                                          _vm._s(
                                                            item2.new_field_value
                                                          ) +
                                                          "\n                                                        "
                                                      )
                                                    ]
                                                  )
                                                ]
                                              )
                                            ]
                                          )
                                        }),
                                        0
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        }),
                        1
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-md-7" }, [
                  _c("div", { staticClass: "row" }, [
                    _c("div", { staticClass: "col-md-8" }, [
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-weight": "bold",
                            "font-style": "italic",
                            "font-size": "0.8rem"
                          }
                        },
                        [_vm._v("Сервисы подвергшияся влиянию:")]
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "border",
                          staticStyle: { height: "250px" }
                        },
                        [
                          _c(
                            "table",
                            { staticClass: "table table-sm table-light" },
                            _vm._l(
                              _vm.troubleticket.service_main_list,
                              function(item, index) {
                                return _c(
                                  "tr",
                                  { key: index, staticClass: "border-bottom" },
                                  [
                                    _c("td", { staticClass: "table__id" }, [
                                      _c("div", [
                                        _c(
                                          "span",
                                          {
                                            staticStyle: {
                                              "font-size": "14px",
                                              "font-weight": "bold"
                                            }
                                          },
                                          [
                                            _vm._v(
                                              "\n                                                        " +
                                                _vm._s(
                                                  item.service_info.service_name
                                                ) +
                                                "\n                                                    "
                                            )
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "span",
                                          {
                                            staticClass:
                                              "badge badge-primary float-right",
                                            staticStyle: {
                                              "font-size": "12px",
                                              "font-style": "italic"
                                            }
                                          },
                                          [
                                            _vm._v(
                                              "\n                                                        " +
                                                _vm._s(
                                                  item.service_info.group_info
                                                    .group_name
                                                ) +
                                                "\n                                                    "
                                            )
                                          ]
                                        )
                                      ]),
                                      _vm._v(" "),
                                      _c("div", {
                                        staticStyle: { clear: "both" }
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticStyle: {
                                            "padding-left": "10px"
                                          }
                                        },
                                        [
                                          _vm._v(
                                            "\n                                                    >>" +
                                              _vm._s(
                                                item.influence_info.group_info
                                                  .trigger_name
                                              ) +
                                              ":: " +
                                              _vm._s(
                                                item.influence_info
                                                  .influence_condition_name
                                              ) +
                                              " \n                                                    "
                                          ),
                                          _c(
                                            "span",
                                            {
                                              staticClass: "float-right",
                                              staticStyle: {
                                                "font-size": "12px",
                                                "font-style": "italic",
                                                "font-weight": "bold"
                                              }
                                            },
                                            [
                                              _vm._v(
                                                "\n                                                        " +
                                                  _vm._s(
                                                    item.formatted_start_date
                                                  ) +
                                                  "\n                                                    "
                                              )
                                            ]
                                          )
                                        ]
                                      )
                                    ])
                                  ]
                                )
                              }
                            ),
                            0
                          )
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-md-4" }, [
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-weight": "bold",
                            "font-style": "italic",
                            "font-size": "0.8rem"
                          }
                        },
                        [_vm._v("Города подвергшияся влиянию:")]
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "border",
                          staticStyle: { height: "250px" }
                        },
                        [
                          _c(
                            "table",
                            { staticClass: "table table-sm table-light" },
                            _vm._l(_vm.ticket_cities, function(item, index) {
                              return _c(
                                "tr",
                                { key: index, staticClass: "border-bottom" },
                                [
                                  _c("td", { staticClass: "table__id" }, [
                                    _vm._v(_vm._s(item.id))
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(
                                      "\n                                                " +
                                        _vm._s(item.city_name)
                                    ),
                                    _c("br"),
                                    _vm._v(" "),
                                    _c(
                                      "span",
                                      {
                                        staticStyle: {
                                          "font-size": "12px",
                                          "font-style": "italic"
                                        }
                                      },
                                      [_vm._v(_vm._s(item.oblast))]
                                    )
                                  ])
                                ]
                              )
                            }),
                            0
                          )
                        ]
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("p"),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "border",
                      staticStyle: { "min-height": "450px", padding: "5px" }
                    },
                    [
                      _vm._m(0),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "tab-content",
                          attrs: { id: "myTabContent" }
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass: "tab-pane fade show active",
                              attrs: {
                                id: "actions",
                                role: "tabpanel",
                                "aria-labelledby": "actions-tab"
                              }
                            },
                            [
                              _c("p"),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  staticStyle: {
                                    height: "350px",
                                    "overflow-y": "auto"
                                  }
                                },
                                [
                                  _c(
                                    "table",
                                    {
                                      staticClass: "table table-sm table-light"
                                    },
                                    _vm._l(_vm.ticket_histories, function(
                                      item,
                                      index
                                    ) {
                                      return _c("tr", { key: index }, [
                                        _c(
                                          "td",
                                          { staticClass: "border-bottom" },
                                          [
                                            _c("div", { staticClass: "row" }, [
                                              _c(
                                                "div",
                                                { staticClass: "col-md-8" },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticStyle: {
                                                        "font-weight": "bold",
                                                        "font-size": "13px",
                                                        color: "#005cb3"
                                                      }
                                                    },
                                                    [
                                                      _c("b-icon", {
                                                        attrs: {
                                                          icon:
                                                            "arrow-up-right-square",
                                                          "aria-hidden": "true"
                                                        }
                                                      }),
                                                      _vm._v(
                                                        "\n                                                                " +
                                                          _vm._s(
                                                            item.action_type_name
                                                          ) +
                                                          ":: \n                                                                "
                                                      ),
                                                      _c(
                                                        "span",
                                                        {
                                                          staticStyle: {
                                                            color: "black"
                                                          }
                                                        },
                                                        [
                                                          _vm._v(
                                                            _vm._s(
                                                              item.action_name
                                                            )
                                                          )
                                                        ]
                                                      )
                                                    ],
                                                    1
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    {
                                                      staticStyle: {
                                                        margin: "0 0 0 25px"
                                                      }
                                                    },
                                                    [
                                                      _c(
                                                        "div",
                                                        {
                                                          staticStyle: {
                                                            padding: "5px",
                                                            "font-size": "14px",
                                                            "font-style":
                                                              "italic"
                                                          }
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                                    " +
                                                              _vm._s(
                                                                item.comment
                                                              ) +
                                                              "\n                                                                "
                                                          )
                                                        ]
                                                      )
                                                    ]
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "div",
                                                { staticClass: "col-md-4" },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "float-right",
                                                      staticStyle: {
                                                        "font-weight": "bold"
                                                      }
                                                    },
                                                    [
                                                      _c(
                                                        "span",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "12px"
                                                          }
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                                    " +
                                                              _vm._s(
                                                                item.user_info
                                                                  .name
                                                              ) +
                                                              "\n                                                                "
                                                          )
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "span",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "12px",
                                                            "font-style":
                                                              "italic"
                                                          }
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                                    // " +
                                                              _vm._s(
                                                                item.formatted_created_date
                                                              ) +
                                                              "\n                                                                "
                                                          )
                                                        ]
                                                      )
                                                    ]
                                                  )
                                                ]
                                              )
                                            ])
                                          ]
                                        )
                                      ])
                                    }),
                                    0
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  staticClass: "float-right",
                                  staticStyle: { padding: "5px 10px" }
                                },
                                [
                                  _c(
                                    "router-link",
                                    {
                                      staticClass:
                                        "btn btn-sm btn-outline-info",
                                      attrs: {
                                        to:
                                          "/troubleticket/update/" +
                                          _vm.troubleticket.id
                                      }
                                    },
                                    [_vm._v("Изменить")]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "button",
                                    {
                                      staticClass:
                                        "btn btn-sm btn-outline-secondary",
                                      staticStyle: { "margin-left": "10px" },
                                      on: { click: function($event) {} }
                                    },
                                    [
                                      _vm._v(
                                        "\n                                            Оставить комментарии \n                                        "
                                      )
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _vm._l(_vm.ticket_actions, function(
                                    action,
                                    index
                                  ) {
                                    return _c(
                                      "button",
                                      {
                                        directives: [
                                          {
                                            name: "b-modal",
                                            rawName:
                                              "v-b-modal.modal-ticket-actions",
                                            modifiers: {
                                              "modal-ticket-actions": true
                                            }
                                          }
                                        ],
                                        key: index,
                                        staticClass:
                                          "btn btn-sm btn-outline-secondary",
                                        staticStyle: { "margin-left": "10px" },
                                        on: {
                                          click: function($event) {
                                            return _vm.changeAction(action)
                                          }
                                        }
                                      },
                                      [
                                        _vm._v(
                                          "\n                                            " +
                                            _vm._s(action.act_title) +
                                            "\n                                        "
                                        )
                                      ]
                                    )
                                  })
                                ],
                                2
                              ),
                              _vm._v(" "),
                              _c(
                                "b-modal",
                                {
                                  attrs: {
                                    id: "modal-ticket-actions",
                                    centered: "",
                                    title:
                                      "Выполнить действие: " +
                                      _vm.selected_action.act_title
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "modal-footer",
                                        fn: function(ref) {
                                          var ok = ref.ok
                                          var cancel = ref.cancel
                                          return [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  size: "sm",
                                                  variant: "info"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return cancel()
                                                  }
                                                }
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                Отменить\n                                            "
                                                )
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  size: "sm",
                                                  variant: "primary"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    _vm.changeAction2()
                                                    ok()
                                                  }
                                                }
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                Подтвердить\n                                            "
                                                )
                                              ]
                                            )
                                          ]
                                        }
                                      }
                                    ],
                                    null,
                                    false,
                                    71707916
                                  )
                                },
                                [
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.action_comment,
                                        expression: "action_comment"
                                      }
                                    ],
                                    staticStyle: { width: "100%" },
                                    attrs: {
                                      placeholder: "Комментарии",
                                      rows: "4"
                                    },
                                    domProps: { value: _vm.action_comment },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.action_comment = $event.target.value
                                      }
                                    }
                                  })
                                ]
                              )
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "tab-pane fade",
                              attrs: {
                                id: "journals",
                                role: "tabpanel",
                                "aria-labelledby": "journals-tab"
                              }
                            },
                            [
                              _c("p"),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  staticStyle: {
                                    height: "350px",
                                    "overflow-y": "auto"
                                  }
                                },
                                [
                                  _c(
                                    "table",
                                    {
                                      staticClass: "table table-sm table-light"
                                    },
                                    _vm._l(_vm.ticket_histories, function(
                                      item,
                                      index
                                    ) {
                                      return _c("tr", { key: index }, [
                                        _c(
                                          "td",
                                          { staticClass: "border-bottom" },
                                          [
                                            _c("div", { staticClass: "row" }, [
                                              _c(
                                                "div",
                                                { staticClass: "col-md-8" },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticStyle: {
                                                        "font-weight": "bold",
                                                        "font-size": "13px",
                                                        color: "#005cb3"
                                                      }
                                                    },
                                                    [
                                                      _c("b-icon", {
                                                        attrs: {
                                                          icon:
                                                            "arrow-up-right-square",
                                                          "aria-hidden": "true"
                                                        }
                                                      }),
                                                      _vm._v(
                                                        "\n                                                                " +
                                                          _vm._s(
                                                            item.action_type_name
                                                          ) +
                                                          ":: \n                                                                "
                                                      ),
                                                      _c(
                                                        "span",
                                                        {
                                                          staticStyle: {
                                                            color: "black"
                                                          }
                                                        },
                                                        [
                                                          _vm._v(
                                                            _vm._s(
                                                              item.action_name
                                                            )
                                                          )
                                                        ]
                                                      )
                                                    ],
                                                    1
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    {
                                                      staticStyle: {
                                                        margin: "0 0 0 25px"
                                                      }
                                                    },
                                                    [
                                                      _c(
                                                        "div",
                                                        {
                                                          staticStyle: {
                                                            padding: "5px",
                                                            "font-size": "14px",
                                                            "font-style":
                                                              "italic"
                                                          }
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                                    " +
                                                              _vm._s(
                                                                item.comment
                                                              ) +
                                                              "\n                                                                "
                                                          )
                                                        ]
                                                      )
                                                    ]
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "div",
                                                { staticClass: "col-md-4" },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "float-right",
                                                      staticStyle: {
                                                        "font-weight": "bold"
                                                      }
                                                    },
                                                    [
                                                      _c(
                                                        "span",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "12px"
                                                          }
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                                    " +
                                                              _vm._s(
                                                                item.user_info
                                                                  .name
                                                              ) +
                                                              "\n                                                                "
                                                          )
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "span",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "12px",
                                                            "font-style":
                                                              "italic"
                                                          }
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                                    // " +
                                                              _vm._s(
                                                                item.formatted_created_date
                                                              ) +
                                                              "\n                                                                "
                                                          )
                                                        ]
                                                      )
                                                    ]
                                                  )
                                                ]
                                              )
                                            ])
                                          ]
                                        )
                                      ])
                                    }),
                                    0
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  staticClass: "float-right",
                                  staticStyle: { padding: "5px 10px" }
                                },
                                [
                                  _c(
                                    "button",
                                    {
                                      directives: [
                                        {
                                          name: "b-modal",
                                          rawName:
                                            "v-b-modal.modal-ticket-journals",
                                          modifiers: {
                                            "modal-ticket-journals": true
                                          }
                                        }
                                      ],
                                      staticClass:
                                        "btn btn-sm btn-outline-secondary",
                                      staticStyle: { "margin-left": "10px" },
                                      on: { click: function($event) {} }
                                    },
                                    [
                                      _vm._v(
                                        "\n                                            Добавить запись\n                                        "
                                      )
                                    ]
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "b-modal",
                                {
                                  attrs: {
                                    id: "modal-ticket-journals",
                                    centered: "",
                                    title: "Добавить запись в журнал"
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "modal-footer",
                                        fn: function(ref) {
                                          var ok = ref.ok
                                          var cancel = ref.cancel
                                          return [
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  size: "sm",
                                                  variant: "info"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return cancel()
                                                  }
                                                }
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                Отменить\n                                            "
                                                )
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "b-button",
                                              {
                                                attrs: {
                                                  size: "sm",
                                                  variant: "primary"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return ok()
                                                  }
                                                }
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                Подтвердить\n                                            "
                                                )
                                              ]
                                            )
                                          ]
                                        }
                                      }
                                    ],
                                    null,
                                    false,
                                    2857976118
                                  )
                                },
                                [
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.journal_comment,
                                        expression: "journal_comment"
                                      }
                                    ],
                                    staticStyle: { width: "100%" },
                                    attrs: {
                                      placeholder: "Комментарии",
                                      rows: "4"
                                    },
                                    domProps: { value: _vm.journal_comment },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.journal_comment =
                                          $event.target.value
                                      }
                                    }
                                  })
                                ]
                              )
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "tab-pane fade",
                              attrs: {
                                id: "subticket",
                                role: "tabpanel",
                                "aria-labelledby": "subticket-tab"
                              }
                            },
                            [
                              _c("p"),
                              _vm._v(" "),
                              !_vm.isSubticketCreate
                                ? _c(
                                    "div",
                                    {
                                      staticStyle: {
                                        height: "350px",
                                        "overflow-y": "auto"
                                      }
                                    },
                                    [
                                      _c(
                                        "table",
                                        {
                                          staticClass:
                                            "table table-sm table-light"
                                        },
                                        _vm._l(_vm.subticket_list, function(
                                          item,
                                          index
                                        ) {
                                          return _c("tr", { key: index }, [
                                            _c(
                                              "td",
                                              { staticClass: "table__id" },
                                              [_vm._v(_vm._s(item.id))]
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "td",
                                              { staticStyle: { width: "40%" } },
                                              [
                                                _c(
                                                  "a",
                                                  { attrs: { href: "#" } },
                                                  [
                                                    _vm._v(
                                                      _vm._s(item.source_name)
                                                    )
                                                  ]
                                                )
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _c("td", [_vm._v("Создан")]),
                                            _vm._v(" "),
                                            _c("td", [
                                              _vm._v(
                                                _vm._s(item.action_label.desc)
                                              )
                                            ]),
                                            _vm._v(" "),
                                            _c("td", [
                                              _vm._v(
                                                _vm._s(
                                                  item.formatted_created_date
                                                )
                                              )
                                            ])
                                          ])
                                        }),
                                        0
                                      )
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              !_vm.isSubticketCreate
                                ? _c(
                                    "div",
                                    {
                                      staticClass: "float-right",
                                      staticStyle: { padding: "5px 10px" }
                                    },
                                    [
                                      _c(
                                        "button",
                                        {
                                          staticClass:
                                            "btn btn-sm btn-outline-info",
                                          staticStyle: {
                                            "margin-left": "10px"
                                          },
                                          on: {
                                            click: function($event) {
                                              _vm.isSubticketCreate = true
                                            }
                                          }
                                        },
                                        [
                                          _vm._v(
                                            "\n                                            Создать ресурсный тикет\n                                        "
                                          )
                                        ]
                                      )
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.isSubticketCreate
                                ? _c(
                                    "div",
                                    {
                                      staticStyle: {
                                        height: "350px",
                                        "overflow-y": "auto"
                                      }
                                    },
                                    [
                                      _c(
                                        "form",
                                        {
                                          on: {
                                            submit: function($event) {
                                              $event.preventDefault()
                                              return _vm.createSubticket()
                                            }
                                          }
                                        },
                                        [
                                          _c("div", { staticClass: "row" }, [
                                            _c(
                                              "div",
                                              { staticClass: "col-md-7" },
                                              [
                                                _c(
                                                  "div",
                                                  { staticClass: "form-group" },
                                                  [
                                                    _c(
                                                      "label",
                                                      {
                                                        attrs: {
                                                          for: "source_name"
                                                        }
                                                      },
                                                      [
                                                        _vm._v(
                                                          "Возможный ресурс проблемы"
                                                        )
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c("input", {
                                                      directives: [
                                                        {
                                                          name: "model",
                                                          rawName: "v-model",
                                                          value:
                                                            _vm.subticket_form
                                                              .source_name,
                                                          expression:
                                                            "subticket_form.source_name"
                                                        }
                                                      ],
                                                      staticClass:
                                                        "form-control",
                                                      attrs: {
                                                        type: "text",
                                                        id: "source_name"
                                                      },
                                                      domProps: {
                                                        value:
                                                          _vm.subticket_form
                                                            .source_name
                                                      },
                                                      on: {
                                                        input: function(
                                                          $event
                                                        ) {
                                                          if (
                                                            $event.target
                                                              .composing
                                                          ) {
                                                            return
                                                          }
                                                          _vm.$set(
                                                            _vm.subticket_form,
                                                            "source_name",
                                                            $event.target.value
                                                          )
                                                        }
                                                      }
                                                    })
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _c(
                                                  "div",
                                                  { staticClass: "form-group" },
                                                  [
                                                    _c(
                                                      "label",
                                                      {
                                                        attrs: {
                                                          for: "description"
                                                        }
                                                      },
                                                      [_vm._v("Описание")]
                                                    ),
                                                    _vm._v(" "),
                                                    _c("textarea", {
                                                      directives: [
                                                        {
                                                          name: "model",
                                                          rawName: "v-model",
                                                          value:
                                                            _vm.subticket_form
                                                              .description,
                                                          expression:
                                                            "subticket_form.description"
                                                        }
                                                      ],
                                                      staticClass:
                                                        "form-control",
                                                      staticStyle: {
                                                        height: "auto"
                                                      },
                                                      attrs: {
                                                        id: "description",
                                                        rows: "4"
                                                      },
                                                      domProps: {
                                                        value:
                                                          _vm.subticket_form
                                                            .description
                                                      },
                                                      on: {
                                                        input: function(
                                                          $event
                                                        ) {
                                                          if (
                                                            $event.target
                                                              .composing
                                                          ) {
                                                            return
                                                          }
                                                          _vm.$set(
                                                            _vm.subticket_form,
                                                            "description",
                                                            $event.target.value
                                                          )
                                                        }
                                                      }
                                                    })
                                                  ]
                                                )
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "div",
                                              { staticClass: "col-md-5" },
                                              [
                                                _c("p"),
                                                _vm._v(" "),
                                                _vm._l(
                                                  _vm.subticket_actions,
                                                  function(action, index) {
                                                    return _c(
                                                      "button",
                                                      {
                                                        key: index,
                                                        staticClass:
                                                          "btn btn-sm btn-outline-secondary",
                                                        staticStyle: {
                                                          margin: "5px 0 0 0",
                                                          width: "100%"
                                                        },
                                                        attrs: {
                                                          type: "submit"
                                                        },
                                                        on: {
                                                          click: function(
                                                            $event
                                                          ) {
                                                            _vm.subticket_action = action
                                                          }
                                                        }
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                        " +
                                                            _vm._s(
                                                              action.act_title
                                                            ) +
                                                            "\n                                                    "
                                                        )
                                                      ]
                                                    )
                                                  }
                                                )
                                              ],
                                              2
                                            )
                                          ])
                                        ]
                                      )
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.isSubticketCreate
                                ? _c(
                                    "div",
                                    {
                                      staticClass: "float-right",
                                      staticStyle: { padding: "5px 10px" }
                                    },
                                    [
                                      _c(
                                        "button",
                                        {
                                          staticClass:
                                            "btn btn-sm btn-outline-danger",
                                          staticStyle: {
                                            "margin-left": "10px"
                                          },
                                          on: {
                                            click: function($event) {
                                              _vm.isSubticketCreate = false
                                            }
                                          }
                                        },
                                        [
                                          _vm._v(
                                            "\n                                            Отменить\n                                        "
                                          )
                                        ]
                                      )
                                    ]
                                  )
                                : _vm._e()
                            ]
                          ),
                          _vm._v(" "),
                          _vm._m(1),
                          _vm._v(" "),
                          _vm._m(2)
                        ]
                      )
                    ]
                  )
                ])
              ])
            ])
          ])
        ])
      : _vm._e()
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "ul",
      { staticClass: "nav nav-tabs", attrs: { id: "myTab", role: "tablist" } },
      [
        _c(
          "li",
          {
            staticClass: "nav-item",
            staticStyle: { "min-width": "130px", "text-align": "center" }
          },
          [
            _c(
              "a",
              {
                staticClass: "nav-link active",
                attrs: {
                  id: "actions-tab",
                  "data-toggle": "tab",
                  href: "#actions",
                  role: "tab",
                  "aria-controls": "actions",
                  "aria-selected": "true"
                }
              },
              [_vm._v("Действия")]
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "li",
          {
            staticClass: "nav-item",
            staticStyle: { "min-width": "130px", "text-align": "center" }
          },
          [
            _c(
              "a",
              {
                staticClass: "nav-link",
                attrs: {
                  id: "journals-tab",
                  "data-toggle": "tab",
                  href: "#journals",
                  role: "tab",
                  "aria-controls": "journals",
                  "aria-selected": "false"
                }
              },
              [_vm._v("Журнал")]
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "li",
          {
            staticClass: "nav-item",
            staticStyle: { "min-width": "130px", "text-align": "center" }
          },
          [
            _c(
              "a",
              {
                staticClass: "nav-link",
                attrs: {
                  id: "subticket-tab",
                  "data-toggle": "tab",
                  href: "#subticket",
                  role: "tab",
                  "aria-controls": "subticket",
                  "aria-selected": "false"
                }
              },
              [_vm._v("Ресурсные тикеты")]
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "li",
          {
            staticClass: "nav-item",
            staticStyle: { "min-width": "130px", "text-align": "center" }
          },
          [
            _c(
              "a",
              {
                staticClass: "nav-link",
                attrs: {
                  id: "conn_tickets-tab",
                  "data-toggle": "tab",
                  href: "#conn_tickets",
                  role: "tab",
                  "aria-controls": "conn_tickets",
                  "aria-selected": "false"
                }
              },
              [_vm._v("Связанные тикеты")]
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "li",
          {
            staticClass: "nav-item",
            staticStyle: { "min-width": "130px", "text-align": "center" }
          },
          [
            _c(
              "a",
              {
                staticClass: "nav-link",
                attrs: {
                  id: "history-tab",
                  "data-toggle": "tab",
                  href: "#history",
                  role: "tab",
                  "aria-controls": "history",
                  "aria-selected": "false"
                }
              },
              [_vm._v("История по объекту")]
            )
          ]
        )
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "tab-pane fade",
        attrs: {
          id: "conn_tickets",
          role: "tabpanel",
          "aria-labelledby": "conn_tickets-tab"
        }
      },
      [
        _c("p"),
        _vm._v(" "),
        _c("table", { staticClass: "table table-sm table-light" }, [
          _c("tr", [
            _c("td", { staticClass: "text-center" }, [_vm._v("Нет данных")])
          ])
        ])
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "tab-pane fade",
        attrs: {
          id: "history",
          role: "tabpanel",
          "aria-labelledby": "history-tab"
        }
      },
      [
        _c("p"),
        _vm._v(" "),
        _c("table", { staticClass: "table table-sm table-light" }, [
          _c("tr", [
            _c("td", { staticClass: "text-center" }, [_vm._v("Нет данных")])
          ])
        ])
      ]
    )
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/troubleticket/views/TicketView.vue":
/*!********************************************************************!*\
  !*** ./resources/js/components/troubleticket/views/TicketView.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TicketView_vue_vue_type_template_id_74eb2d09_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TicketView.vue?vue&type=template&id=74eb2d09&scoped=true& */ "./resources/js/components/troubleticket/views/TicketView.vue?vue&type=template&id=74eb2d09&scoped=true&");
/* harmony import */ var _TicketView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TicketView.vue?vue&type=script&lang=js& */ "./resources/js/components/troubleticket/views/TicketView.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TicketView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TicketView_vue_vue_type_template_id_74eb2d09_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TicketView_vue_vue_type_template_id_74eb2d09_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "74eb2d09",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/troubleticket/views/TicketView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/troubleticket/views/TicketView.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/components/troubleticket/views/TicketView.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TicketView.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketView.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/troubleticket/views/TicketView.vue?vue&type=template&id=74eb2d09&scoped=true&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/components/troubleticket/views/TicketView.vue?vue&type=template&id=74eb2d09&scoped=true& ***!
  \***************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketView_vue_vue_type_template_id_74eb2d09_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TicketView.vue?vue&type=template&id=74eb2d09&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/troubleticket/views/TicketView.vue?vue&type=template&id=74eb2d09&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketView_vue_vue_type_template_id_74eb2d09_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TicketView_vue_vue_type_template_id_74eb2d09_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/helpers/mixins/TheContentMixin.vue":
/*!*********************************************************!*\
  !*** ./resources/js/helpers/mixins/TheContentMixin.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TheContentMixin.vue?vue&type=script&lang=js& */ "./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
var render, staticRenderFns




/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  _TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"],
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/helpers/mixins/TheContentMixin.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TheContentMixin.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ })

}]);