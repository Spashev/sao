(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[7],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _schemeStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./schemeStore */ "./resources/js/components/scheme/schemeStore.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _helpers_mixins_TheContentMixin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../helpers/mixins/TheContentMixin */ "./resources/js/helpers/mixins/TheContentMixin.vue");
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue-loading-overlay */ "./node_modules/vue-loading-overlay/dist/vue-loading.min.js");
/* harmony import */ var vue_loading_overlay__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vue-loading-overlay/dist/vue-loading.css */ "./node_modules/vue-loading-overlay/dist/vue-loading.css");
/* harmony import */ var vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(vue_loading_overlay_dist_vue_loading_css__WEBPACK_IMPORTED_MODULE_7__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

axios__WEBPACK_IMPORTED_MODULE_1___default.a.defaults.withCredentials = true;






/* harmony default export */ __webpack_exports__["default"] = ({
  name: "List",
  mixins: [_helpers_mixins_TheContentMixin__WEBPACK_IMPORTED_MODULE_5__["default"]],
  data: function data() {
    return {
      breadcrumbs: [{
        text: 'Главная',
        to: {
          path: '/'
        }
      }, {
        text: 'Схема',
        active: true
      }],
      modalVisibility: false,
      updateMode: false,
      form: {
        name: '',
        description: ''
      },
      selectedComponentId: null,
      formErrors: null,
      errors: null,
      isLoading: true
    };
  },
  components: {
    Loading: vue_loading_overlay__WEBPACK_IMPORTED_MODULE_6___default.a
  },
  mounted: function mounted() {
    this.generateBreadcrumb(this.breadcrumbs);
    this.fetchData();
  },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_4__["mapGetters"])(["components"])),
  methods: {
    fetchData: function fetchData() {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this.$store.dispatch(_schemeStore__WEBPACK_IMPORTED_MODULE_2__["SET_COMPONENTS"]);

              case 2:
                _this.isLoading = false;

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    showCreateModal: function showCreateModal() {
      this.selectedComponentId = null;
      this.updateMode = false;
      this.resetForm();
      this.modalVisibility = true;
    },
    createComponent: function createComponent() {
      var _this2 = this;

      this.formErrors = null;
      this.$v.form.$touch();
      if (this.$v.form.$pending || this.$v.form.$error) return;
      this.isLoading = true;
      axios__WEBPACK_IMPORTED_MODULE_1___default.a.post('/api/scheme/components/create', this.$data.form).then(function (response) {
        if (response.data.success === 1) {
          var components = _this2.$store.getters.components;
          components.push(response.data.component);
          _this2.modalVisibility = false;

          _this2.resetForm();

          _this2.isLoading = false;
        }
      })["catch"](function (error) {
        if (error.response.data) {
          _this2.formErrors = error.response.data.errors;
          _this2.isLoading = false;
          return;
        }
      });
    },
    updateComponentModal: function updateComponentModal(component) {
      this.updateMode = true;
      this.resetForm();
      this.form.id = this.selectedComponentId = component.id;
      this.form.name = component.comp_name;
      this.form.description = component.comp_desc;
      this.modalVisibility = true;
    },
    updateComponent: function updateComponent() {
      var _this3 = this;

      this.formErrors = null;
      this.$v.form.$touch();
      if (this.$v.form.$pending || this.$v.form.$error) return;
      this.isLoading = true;
      axios__WEBPACK_IMPORTED_MODULE_1___default.a.post('/api/scheme/components/update/' + this.selectedComponentId, this.$data.form).then(function (response) {
        if (response.data.success === 1) {
          var components = _this3.$store.getters.components;
          var componentIndex = components.findIndex(function (component) {
            return component.id === _this3.selectedComponentId;
          });
          components.splice(componentIndex, 1);
          components.push(response.data.component);
          components.sort(function (n1, n2) {
            return n1.id - n2.id;
          });
          _this3.modalVisibility = false;

          _this3.resetForm();

          _this3.selectedComponentId = null;
          _this3.updateMode = false;
          _this3.isLoading = false;
        }
      })["catch"](function (error) {
        if (error.response.data) {
          _this3.formErrors = error.response.data.errors;
          _this3.isLoading = false;
          return;
        }
      });
    },
    confirmDelete: function confirmDelete(id) {
      var _this4 = this;

      this.selectedComponentId = id;
      this.$nextTick(function () {
        _this4.$bvModal.show('modal-confirm-deletion');
      });
    },
    deleteComponent: function deleteComponent() {
      var _this5 = this;

      this.errors = null;
      axios__WEBPACK_IMPORTED_MODULE_1___default.a.post('/api/scheme/components/' + this.selectedComponentId).then(function (response) {
        if (response.data.success === 1) {
          var components = _this5.$store.getters.components;
          var componentIndex = components.findIndex(function (component) {
            return component.id === _this5.selectedComponentId;
          });
          components.splice(componentIndex, 1);
          _this5.selectedComponentId = null;
        }
      })["catch"](function (error) {
        if (error.response.data.messages) {
          _this5.errors = error.response.data.messages;
          return;
        }
      });
    },
    resetForm: function resetForm() {
      var self = this;
      Object.keys(this.$data.form).forEach(function (key, index) {
        self.$data.form[key] = '';
      });
    }
  },
  validations: {
    form: {
      name: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__["required"],
        minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__["minLength"])(3),
        maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__["maxLength"])(255)
      },
      description: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__["required"],
        minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__["minLength"])(3),
        maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__["maxLength"])(4000)
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helpers */ "./resources/js/helpers/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: "TheContentMixin",
  methods: {
    generateBreadcrumb: function generateBreadcrumb(breadcrumbs) {
      this.$store.dispatch(_helpers__WEBPACK_IMPORTED_MODULE_0__["SET_BREADCRUMBS"], breadcrumbs);
    },
    getTitle: function getTitle(breadcrumbs) {
      return breadcrumbs[breadcrumbs.length - 1].text;
    },
    setNotifications: function setNotifications(notifications) {
      this.$store.dispatch(_helpers__WEBPACK_IMPORTED_MODULE_0__["SET_NOTIFICATIONS"], notifications);
    },
    scrollToTop: function scrollToTop() {
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.modal[data-v-b2a991ce] {\n    display: block;\n}\n.alert[data-v-b2a991ce] {\n    font-size: 0.9rem;\n}\n.errors[data-v-b2a991ce] {\n    background: #FF2205;\n    border-radius: 5px;\n    padding: 21px 0 2px 0;\n}\n.nav-pills .nav-link[data-v-b2a991ce] {\n    background-color: rgba(0, 0, 0, .03);\n    padding: .2rem 1rem;\n    border: 1px solid rgba(0, 0, 0, 0.125);\n}\n.nav-pills .nav-link.active[data-v-b2a991ce] {\n    border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;\n}\n.nav-pills .nav-item .btn[data-v-b2a991ce] {\n    display: flex;\n}\n.list-group-item[data-v-b2a991ce] {\n    border: 1px solid rgba(0, 0, 0, .125) !important;\n    padding: 0.05rem 1.25rem;\n    font-size: 0.8em;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--5-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--5-2!../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=template&id=b2a991ce&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=template&id=b2a991ce&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("loading", {
        attrs: { active: _vm.isLoading, "can-cancel": false },
        on: {
          "update:active": function($event) {
            _vm.isLoading = $event
          }
        }
      }),
      _vm._v(" "),
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-12" }, [
          _c("div", { staticClass: "card" }, [
            _c("div", { staticClass: "card-header" }, [
              _vm._v(
                _vm._s(this.getTitle(this.breadcrumbs)) +
                  "\n                    "
              ),
              _c(
                "button",
                {
                  staticClass: "btn btn-sm btn-outline-primary float-right",
                  on: { click: _vm.showCreateModal }
                },
                [_vm._v("Добавить\n                    ")]
              )
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _vm.errors
                ? _c("div", { staticClass: "alert alert-danger m-2" }, [
                    _vm._v(
                      "\n                        " +
                        _vm._s(_vm.errors) +
                        "\n                    "
                    )
                  ])
                : _vm._e(),
              _vm._v(" "),
              _c("div", { staticClass: "table-responsive" }, [
                _c("table", { staticClass: "table table-bordered" }, [
                  _vm._m(0),
                  _vm._v(" "),
                  _vm.components
                    ? _c(
                        "tbody",
                        _vm._l(_vm.components, function(item, index) {
                          return _c("tr", { key: index }, [
                            _c("td", { staticClass: "table__id" }, [
                              _vm._v(_vm._s(item.id))
                            ]),
                            _vm._v(" "),
                            _c(
                              "td",
                              [
                                _c(
                                  "router-link",
                                  { attrs: { to: "/scheme/" + item.id } },
                                  [_vm._v(_vm._s(item.comp_name))]
                                )
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(item.comp_desc))]),
                            _vm._v(" "),
                            _c(
                              "td",
                              [
                                _c(
                                  "router-link",
                                  { attrs: { to: "/scheme/" + item.id } },
                                  [
                                    _c(
                                      "b-button",
                                      {
                                        staticClass: "p-1",
                                        attrs: {
                                          variant: "outline-secondary",
                                          size: "sm"
                                        }
                                      },
                                      [
                                        _c("b-icon", {
                                          attrs: {
                                            icon: "eye",
                                            "aria-hidden": "true"
                                          }
                                        })
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "b-button",
                                  {
                                    staticClass: "p-1",
                                    attrs: {
                                      variant: "outline-secondary",
                                      size: "sm"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.updateComponentModal(item)
                                      }
                                    }
                                  },
                                  [
                                    _c("b-icon", {
                                      attrs: {
                                        icon: "pencil",
                                        "aria-hidden": "true"
                                      }
                                    })
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "b-button",
                                  {
                                    staticClass: "p-1",
                                    attrs: {
                                      variant: "outline-secondary",
                                      size: "sm"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.confirmDelete(item.id)
                                      }
                                    }
                                  },
                                  [
                                    _c("b-icon", {
                                      attrs: {
                                        icon: "trash",
                                        "aria-hidden": "true"
                                      }
                                    })
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ])
                        }),
                        0
                      )
                    : _c("tfoot", [
                        _c(
                          "td",
                          {
                            staticClass: "text-center",
                            attrs: { colspan: "3" }
                          },
                          [_vm._v("Данные отсутствуют")]
                        )
                      ])
                ])
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _vm.modalVisibility
        ? _c(
            "div",
            {
              staticClass: "modal fade show",
              attrs: { tabindex: "-1", role: "dialog" }
            },
            [
              _c(
                "div",
                { staticClass: "modal-dialog", attrs: { role: "document" } },
                [
                  _c(
                    "form",
                    {
                      on: {
                        submit: function($event) {
                          $event.preventDefault()
                          _vm.updateMode
                            ? _vm.updateComponent()
                            : _vm.createComponent()
                        }
                      }
                    },
                    [
                      _c("div", { staticClass: "modal-content" }, [
                        _c("div", { staticClass: "modal-header" }, [
                          _c("h5", { staticClass: "modal-title" }, [
                            _vm._v(
                              _vm._s(
                                _vm.updateMode
                                  ? "Изменить компонент"
                                  : "Создать компонент"
                              )
                            )
                          ]),
                          _vm._v(" "),
                          _c(
                            "button",
                            {
                              staticClass: "close",
                              attrs: {
                                type: "button",
                                "data-dismiss": "modal",
                                "aria-label": "Close"
                              },
                              on: {
                                click: function($event) {
                                  _vm.modalVisibility = false
                                }
                              }
                            },
                            [
                              _c("span", { attrs: { "aria-hidden": "true" } }, [
                                _vm._v("×")
                              ])
                            ]
                          )
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "modal-body" }, [
                          _vm.updateMode
                            ? _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.form.id,
                                    expression: "form.id"
                                  }
                                ],
                                staticClass: "form-control",
                                attrs: { type: "hidden" },
                                domProps: { value: _vm.form.id },
                                on: {
                                  input: function($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.form,
                                      "id",
                                      $event.target.value
                                    )
                                  }
                                }
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _c("div", { staticClass: "form-group" }, [
                            _c("label", { attrs: { for: "name" } }, [
                              _vm._v("Название")
                            ]),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.form.name,
                                  expression: "form.name"
                                }
                              ],
                              staticClass: "form-control",
                              class: { "is-invalid": _vm.$v.form.name.$error },
                              attrs: { type: "text", id: "name" },
                              domProps: { value: _vm.form.name },
                              on: {
                                blur: function($event) {
                                  return _vm.$v.form.name.$touch()
                                },
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.form,
                                    "name",
                                    $event.target.value
                                  )
                                }
                              }
                            }),
                            _vm._v(" "),
                            !_vm.$v.form.name.required
                              ? _c("div", { staticClass: "invalid-feedback" }, [
                                  _vm._v(
                                    "Обязательно для заполнения\n                            "
                                  )
                                ])
                              : _vm._e(),
                            _vm._v(" "),
                            !_vm.$v.form.name.minLength
                              ? _c("div", { staticClass: "invalid-feedback" }, [
                                  _vm._v(
                                    "\n                                Минимальная длина " +
                                      _vm._s(
                                        _vm.$v.form.name.$params.minLength.min
                                      ) +
                                      " символов. Сейчас " +
                                      _vm._s(_vm.form.name.length) +
                                      ".\n                            "
                                  )
                                ])
                              : _vm._e(),
                            _vm._v(" "),
                            !_vm.$v.form.name.maxLength
                              ? _c("div", { staticClass: "invalid-feedback" }, [
                                  _vm._v(
                                    "\n                                Максимальная длина " +
                                      _vm._s(
                                        _vm.$v.form.name.$params.maxLength.max
                                      ) +
                                      " символов. Сейчас " +
                                      _vm._s(_vm.form.name.length) +
                                      ".\n                            "
                                  )
                                ])
                              : _vm._e()
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "form-group" }, [
                            _c("label", { attrs: { for: "description" } }, [
                              _vm._v("Описание")
                            ]),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.form.description,
                                  expression: "form.description"
                                }
                              ],
                              staticClass: "form-control",
                              class: {
                                "is-invalid": _vm.$v.form.description.$error
                              },
                              attrs: { type: "text", id: "description" },
                              domProps: { value: _vm.form.description },
                              on: {
                                blur: function($event) {
                                  return _vm.$v.form.description.$touch()
                                },
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.form,
                                    "description",
                                    $event.target.value
                                  )
                                }
                              }
                            }),
                            _vm._v(" "),
                            !_vm.$v.form.description.required
                              ? _c("div", { staticClass: "invalid-feedback" }, [
                                  _vm._v(
                                    "Обязательно для\n                                заполнения\n                            "
                                  )
                                ])
                              : _vm._e(),
                            _vm._v(" "),
                            !_vm.$v.form.description.minLength
                              ? _c("div", { staticClass: "invalid-feedback" }, [
                                  _vm._v(
                                    "\n                                Минимальная длина " +
                                      _vm._s(
                                        _vm.$v.form.description.$params
                                          .minLength.min
                                      ) +
                                      " символов. Сейчас\n                                " +
                                      _vm._s(_vm.form.description.length) +
                                      ".\n                            "
                                  )
                                ])
                              : _vm._e(),
                            _vm._v(" "),
                            !_vm.$v.form.description.maxLength
                              ? _c("div", { staticClass: "invalid-feedback" }, [
                                  _vm._v(
                                    "\n                                Максимальная длина " +
                                      _vm._s(
                                        _vm.$v.form.description.$params
                                          .maxLength.max
                                      ) +
                                      " символов. Сейчас\n                                " +
                                      _vm._s(_vm.form.description.length) +
                                      ".\n                            "
                                  )
                                ])
                              : _vm._e()
                          ]),
                          _vm._v(" "),
                          _vm.formErrors
                            ? _c(
                                "div",
                                { staticClass: "alert alert-danger" },
                                _vm._l(_vm.formErrors, function(
                                  fieldsError,
                                  fieldName
                                ) {
                                  return _c("div", { key: fieldName }, [
                                    _vm._v(
                                      "\n                                " +
                                        _vm._s(fieldsError.join("\n")) +
                                        "\n                            "
                                    )
                                  ])
                                }),
                                0
                              )
                            : _vm._e()
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "modal-footer" }, [
                          _c(
                            "button",
                            {
                              staticClass: "btn btn-sm btn-outline-dark",
                              on: {
                                click: function($event) {
                                  _vm.modalVisibility = false
                                }
                              }
                            },
                            [_vm._v("Отмена")]
                          ),
                          _vm._v(" "),
                          _c(
                            "button",
                            { staticClass: "btn btn-sm btn-outline-primary" },
                            [
                              _vm._v(
                                _vm._s(
                                  _vm.updateMode ? "Изменить" : "Сохранить"
                                )
                              )
                            ]
                          )
                        ])
                      ])
                    ]
                  )
                ]
              )
            ]
          )
        : _vm._e(),
      _vm._v(" "),
      _vm.modalVisibility
        ? _c("div", { staticClass: "modal-backdrop fade show" })
        : _vm._e(),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          ref: "modal",
          attrs: {
            id: "modal-confirm-deletion",
            title: "",
            "ok-title": "Да",
            "cancel-title": "Нет"
          },
          on: { ok: _vm.deleteComponent }
        },
        [_c("h5", [_vm._v("Вы действительно хотите удалить Компонент?")])]
      )
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { staticClass: "table__id" }, [_vm._v("ID")]),
        _vm._v(" "),
        _c("th", [_vm._v("Name")]),
        _vm._v(" "),
        _c("th", [_vm._v("Description")]),
        _vm._v(" "),
        _c("th", { staticStyle: { width: "100px" } })
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/scheme/TheComponentList.vue":
/*!*************************************************************!*\
  !*** ./resources/js/components/scheme/TheComponentList.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TheComponentList_vue_vue_type_template_id_b2a991ce_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TheComponentList.vue?vue&type=template&id=b2a991ce&scoped=true& */ "./resources/js/components/scheme/TheComponentList.vue?vue&type=template&id=b2a991ce&scoped=true&");
/* harmony import */ var _TheComponentList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TheComponentList.vue?vue&type=script&lang=js& */ "./resources/js/components/scheme/TheComponentList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _TheComponentList_vue_vue_type_style_index_0_id_b2a991ce_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css& */ "./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TheComponentList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TheComponentList_vue_vue_type_template_id_b2a991ce_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TheComponentList_vue_vue_type_template_id_b2a991ce_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "b2a991ce",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/scheme/TheComponentList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/scheme/TheComponentList.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/scheme/TheComponentList.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TheComponentList.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css&":
/*!**********************************************************************************************************************!*\
  !*** ./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css& ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_style_index_0_id_b2a991ce_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--5-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--5-2!../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=style&index=0&id=b2a991ce&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_style_index_0_id_b2a991ce_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_style_index_0_id_b2a991ce_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_style_index_0_id_b2a991ce_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_5_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_2_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_style_index_0_id_b2a991ce_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/components/scheme/TheComponentList.vue?vue&type=template&id=b2a991ce&scoped=true&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/components/scheme/TheComponentList.vue?vue&type=template&id=b2a991ce&scoped=true& ***!
  \********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_template_id_b2a991ce_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TheComponentList.vue?vue&type=template&id=b2a991ce&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/components/scheme/TheComponentList.vue?vue&type=template&id=b2a991ce&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_template_id_b2a991ce_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheComponentList_vue_vue_type_template_id_b2a991ce_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/helpers/mixins/TheContentMixin.vue":
/*!*********************************************************!*\
  !*** ./resources/js/helpers/mixins/TheContentMixin.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TheContentMixin.vue?vue&type=script&lang=js& */ "./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
var render, staticRenderFns




/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  _TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"],
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/helpers/mixins/TheContentMixin.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!../../../../node_modules/vue-svg-inline-loader/dist/index.min.js!./TheContentMixin.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./node_modules/vue-svg-inline-loader/dist/index.min.js!./resources/js/helpers/mixins/TheContentMixin.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_vue_svg_inline_loader_dist_index_min_js_TheContentMixin_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ })

}]);